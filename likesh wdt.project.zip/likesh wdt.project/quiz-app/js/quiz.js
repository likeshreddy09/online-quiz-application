// Quiz Selection Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    loadQuizzes();
    setupSearchFunctionality();
});

function loadQuizzes() {
    const quizContainer = document.getElementById('quizContainer');
    
    // Sample quiz data (in real app, fetch from server)
    const quizzes = [
        {
            id: 1,
            title: 'General Knowledge',
            description: 'Test your general knowledge across various topics',
            category: 'General',
            questions: 20,
            difficulty: 'Medium',
            passingScore: 60,
            timeLimit: 30,
            attempts: 1245,
            rating: 4.5
        },
        {
            id: 2,
            title: 'JavaScript Basics',
            description: 'Master the fundamentals of JavaScript programming',
            category: 'Programming',
            questions: 25,
            difficulty: 'Intermediate',
            passingScore: 70,
            timeLimit: 45,
            attempts: 892,
            rating: 4.7
        },
        {
            id: 3,
            title: 'World History',
            description: 'Explore important events and figures in world history',
            category: 'History',
            questions: 30,
            difficulty: 'Easy',
            passingScore: 55,
            timeLimit: 40,
            attempts: 567,
            rating: 4.3
        },
        {
            id: 4,
            title: 'English Grammar',
            description: 'Perfect your English grammar and language skills',
            category: 'Language',
            questions: 20,
            difficulty: 'Medium',
            passingScore: 65,
            timeLimit: 35,
            attempts: 734,
            rating: 4.6
        },
        {
            id: 5,
            title: 'Chemistry Fundamentals',
            description: 'Learn basic concepts of chemistry',
            category: 'Science',
            questions: 25,
            difficulty: 'Intermediate',
            passingScore: 70,
            timeLimit: 50,
            attempts: 612,
            rating: 4.4
        },
        {
            id: 6,
            title: 'Biology Basics',
            description: 'Understand living organisms and biological processes',
            category: 'Science',
            questions: 22,
            difficulty: 'Easy',
            passingScore: 60,
            timeLimit: 40,
            attempts: 891,
            rating: 4.5
        },
        {
            id: 7,
            title: 'Python Programming',
            description: 'Learn Python programming from basics to advanced',
            category: 'Programming',
            questions: 30,
            difficulty: 'Intermediate',
            passingScore: 70,
            timeLimit: 60,
            attempts: 1005,
            rating: 4.8
        },
        {
            id: 8,
            title: 'World Capitals',
            description: 'Test your knowledge of world capitals and geography',
            category: 'Geography',
            questions: 20,
            difficulty: 'Easy',
            passingScore: 60,
            timeLimit: 25,
            attempts: 1432,
            rating: 4.6
        },
        {
            id: 9,
            title: 'Mathematics Advanced',
            description: 'Challenge yourself with advanced math problems',
            category: 'Mathematics',
            questions: 25,
            difficulty: 'Hard',
            passingScore: 75,
            timeLimit: 60,
            attempts: 445,
            rating: 4.2
        },
        {
            id: 10,
            title: 'Art & Culture',
            description: 'Explore famous artworks and cultural movements',
            category: 'Culture',
            questions: 20,
            difficulty: 'Medium',
            passingScore: 65,
            timeLimit: 30,
            attempts: 567,
            rating: 4.4
        }
    ];

    // Store quizzes in window for global access
    window.quizzesData = quizzes;
    localStorage.setItem('quizMasterQuizzes', JSON.stringify(quizzes));

    // Render quizzes
    quizContainer.innerHTML = '';
    quizzes.forEach(quiz => {
        const quizCard = createQuizCard(quiz);
        quizContainer.innerHTML += quizCard;
    });

    // Add event listeners to quiz cards
    document.querySelectorAll('.quiz-start-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const quizId = this.dataset.quizId;
            startQuiz(quizId);
        });
    });

    document.querySelectorAll('.existing-quiz-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const quizId = this.dataset.quizId;
            // Open existing quiz (same as Start Quiz for now)
            startQuiz(quizId);
        });
    });
}

function createQuizCard(quiz) {
    const difficultyColor = {
        'Easy': 'success',
        'Medium': 'warning',
        'Intermediate': 'info',
        'Hard': 'danger'
    };

    return `
        <div class="col-md-6 mb-4">
            <div class="quiz-item">
                <div class="quiz-header">
                    <h5>${quiz.title}</h5>
                    <span class="badge bg-${difficultyColor[quiz.difficulty] || 'secondary'}">
                        ${quiz.difficulty}
                    </span>
                </div>
                <div class="quiz-body">
                    <p class="text-muted">${quiz.description}</p>
                    
                    <div class="quiz-stats">
                        <div class="quiz-stat">
                            <div class="quiz-stat-number">${quiz.questions}</div>
                            <div class="quiz-stat-label">Questions</div>
                        </div>
                        <div class="quiz-stat">
                            <div class="quiz-stat-number">${quiz.timeLimit}m</div>
                            <div class="quiz-stat-label">Time Limit</div>
                        </div>
                        <div class="quiz-stat">
                            <div class="quiz-stat-number">${quiz.attempts}</div>
                            <div class="quiz-stat-label">Attempts</div>
                        </div>
                    </div>

                    <div class="d-flex align-items-center justify-content-between my-3">
                        <span class="text-warning">
                            ${'⭐'.repeat(Math.floor(quiz.rating))} ${quiz.rating}
                        </span>
                        <span class="badge bg-secondary">
                            ${quiz.passingScore}% Pass
                        </span>
                    </div>

                    <div class="d-flex gap-2">
                        <button class="btn btn-outline-info w-50 existing-quiz-btn" data-quiz-id="${quiz.id}">
                            Existing Quiz
                        </button>
                        <button class="btn btn-primary w-50 quiz-start-btn" data-quiz-id="${quiz.id}">
                            Start Quiz
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function setupSearchFunctionality() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            filterQuizzes(this.value);
        });
    }
}

function filterQuizzes(searchTerm) {
    const quizContainer = document.getElementById('quizContainer');
    const noResults = document.getElementById('noResults');
    
    if (!quizContainer) return;

    const quizItems = quizContainer.querySelectorAll('.quiz-item');
    let visibleCount = 0;

    quizItems.forEach(item => {
        const parent = item.closest('.col-md-6');
        const title = item.querySelector('h5').textContent.toLowerCase();
        const description = item.querySelector('.text-muted').textContent.toLowerCase();
        
        if (title.includes(searchTerm.toLowerCase()) || 
            description.includes(searchTerm.toLowerCase())) {
            parent.style.display = 'block';
            visibleCount++;
        } else {
            parent.style.display = 'none';
        }
    });

    if (visibleCount === 0) {
        noResults.style.display = 'block';
    } else {
        noResults.style.display = 'none';
    }
}

function startQuiz(quizId) {
    sessionStorage.setItem('selectedQuizId', quizId);
    window.location.href = 'quiz.html';
}

function exitQuiz() {
    if (confirm('Are you sure you want to exit the quiz? Your progress will be lost.')) {
        window.location.href = 'quiz-selection.html';
    }
}
