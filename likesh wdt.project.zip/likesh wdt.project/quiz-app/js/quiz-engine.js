// Quiz Engine - Main Quiz Logic

let quizState = {
    currentQuestionIndex: 0,
    totalScore: 0,
    answers: [],
    startTime: Date.now(),
    timeRemaining: 0,
    timerInterval: null,
    currentQuiz: null,
    questions: []
};

document.addEventListener('DOMContentLoaded', function() {
    initializeQuiz();
});

function initializeQuiz() {
    const quizId = sessionStorage.getItem('selectedQuizId');
    const quizzes = window.quizzesData || JSON.parse(localStorage.getItem('quizMasterQuizzes') || '[]');
    
    quizState.currentQuiz = quizzes.find(q => q.id === parseInt(quizId));

    // If not found in memory, try fallback with default quiz list from this file
    if (!quizState.currentQuiz && quizzes.length === 0) {
        window.quizzesData = getDefaultQuizList();
        quizState.currentQuiz = window.quizzesData.find(q => q.id === parseInt(quizId));
    }
    
    if (!quizState.currentQuiz) {
        window.location.href = 'quiz-selection.html';
        return;
    }

    loadQuizData();
    displayQuestion();
    startTimer();
}

function loadQuizData() {
    const quiz = quizState.currentQuiz;
    
    // Sample questions (in real app, fetch from server)
    const sampleQuestions = [
        {
            id: 1,
            question: 'What is the capital of France?',
            options: ['London', 'Berlin', 'Paris', 'Madrid'],
            correctAnswer: 2,
            explanation: 'Paris is the capital and largest city of France.',
            points: 10
        },
        {
            id: 2,
            question: 'Which planet is closest to the Sun?',
            options: ['Venus', 'Mercury', 'Earth', 'Mars'],
            correctAnswer: 1,
            explanation: 'Mercury is the planet closest to the Sun.',
            points: 10
        },
        {
            id: 3,
            question: 'What is 15 + 27?',
            options: ['32', '42', '52', '62'],
            correctAnswer: 1,
            explanation: 'The sum of 15 and 27 is 42.',
            points: 5
        },
        {
            id: 4,
            question: 'Who wrote \"Romeo and Juliet\"?',
            options: ['Mark Twain', 'William Shakespeare', 'Jane Austen', 'Oscar Wilde'],
            correctAnswer: 1,
            explanation: 'William Shakespeare wrote \"Romeo and Juliet\" in the early 1600s.',
            points: 10
        },
        {
            id: 5,
            question: 'Which is the largest ocean?',
            options: ['Atlantic Ocean', 'Pacific Ocean', 'Indian Ocean', 'Arctic Ocean'],
            correctAnswer: 1,
            explanation: 'The Pacific Ocean is the largest ocean on Earth.',
            points: 10
        },
        {
            id: 6,
            question: 'What is the chemical symbol for Gold?',
            options: ['Go', 'Gd', 'Au', 'Ag'],
            correctAnswer: 2,
            explanation: 'The chemical symbol for Gold is Au, from the Latin word \"Aurum\".',
            points: 10
        },
        {
            id: 7,
            question: 'In which year did World War II end?',
            options: ['1943', '1944', '1945', '1946'],
            correctAnswer: 2,
            explanation: 'World War II ended in 1945.',
            points: 10
        },
        {
            id: 8,
            question: 'What is the smallest prime number?',
            options: ['0', '1', '2', '3'],
            correctAnswer: 2,
            explanation: 'The smallest prime number is 2. Prime numbers are only divisible by 1 and themselves.',
            points: 10
        },
        {
            id: 9,
            question: 'Which country is home to the Great Wall?',
            options: ['Japan', 'China', 'Korea', 'India'],
            correctAnswer: 1,
            explanation: 'The Great Wall of China is located in China and is one of the most impressive structures in the world.',
            points: 10
        },
        {
            id: 10,
            question: 'What does HTTP stand for?',
            options: ['High Transfer Text Protocol', 'HyperText Transfer Protocol', 'Home Tool Transfer Protocol', 'High Technology Text Protocol'],
            correctAnswer: 1,
            explanation: 'HTTP stands for HyperText Transfer Protocol, the foundation of data communication on the web.',
            points: 10
        }
    ];

    quizState.questions = sampleQuestions;
    quizState.answers = new Array(sampleQuestions.length).fill(null);
    quizState.timeRemaining = quiz.timeLimit * 60;

    // Update header
    document.getElementById('quizTitle').textContent = quiz.title;
    const quizNameElement = document.getElementById('quizName');
    if (quizNameElement) {
        quizNameElement.textContent = quiz.title;
    }
    document.getElementById('totalQuestions').textContent = sampleQuestions.length;
}

function displayQuestion() {
    const index = quizState.currentQuestionIndex;
    const question = quizState.questions[index];

    if (!question) return;

    // Update header
    document.getElementById('currentQuestion').textContent = index + 1;
    document.getElementById('questionText').textContent = question.question;
    
    // Update progress bar
    const progress = Math.round(((index + 1) / quizState.questions.length) * 100);
    document.getElementById('progressBar').style.width = progress + '%';
    document.getElementById('progressText').textContent = progress + '%';

    // Display options
    const optionsContainer = document.getElementById('optionsContainer');
    optionsContainer.innerHTML = '';

    question.options.forEach((option, optionIndex) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'option-btn';
        button.textContent = option;
        button.onclick = () => selectAnswer(optionIndex);

        if (quizState.answers[index] === optionIndex) {
            button.classList.add('selected');
        }

        optionsContainer.appendChild(button);
    });

    // Update button visibility
    updateNavigationButtons();
}

function selectAnswer(optionIndex) {
    quizState.answers[quizState.currentQuestionIndex] = optionIndex;
    
    // Update UI
    document.querySelectorAll('.option-btn').forEach((btn, idx) => {
        btn.classList.remove('selected');
        if (idx === optionIndex) {
            btn.classList.add('selected');
        }
    });
}

function nextQuestion() {
    if (quizState.currentQuestionIndex < quizState.questions.length - 1) {
        quizState.currentQuestionIndex++;
        displayQuestion();
    }
}

function previousQuestion() {
    if (quizState.currentQuestionIndex > 0) {
        quizState.currentQuestionIndex--;
        displayQuestion();
    }
}

function skipQuestion() {
    quizState.answers[quizState.currentQuestionIndex] = null;
    nextQuestion();
}

function updateNavigationButtons() {
    const index = quizState.currentQuestionIndex;
    const total = quizState.questions.length;

    document.getElementById('prevBtn').disabled = index === 0;
    document.getElementById('submitBtn').style.display = index === total - 1 ? 'block' : 'none';
    document.getElementById('nextBtn').style.display = index === total - 1 ? 'none' : 'block';
}

function startTimer() {
    quizState.timerInterval = setInterval(updateTimer, 1000);
}

function updateTimer() {
    quizState.timeRemaining--;

    const minutes = Math.floor(quizState.timeRemaining / 60);
    const seconds = quizState.timeRemaining % 60;
    document.getElementById('timer').textContent = 
        `${minutes}:${seconds.toString().padStart(2, '0')}`;

    if (quizState.timeRemaining <= 0) {
        clearInterval(quizState.timerInterval);
        submitQuiz();
    }

    // Change color if time running out
    if (quizState.timeRemaining < 60) {
        document.getElementById('timer').style.color = '#dc3545';
    }
}

function submitQuiz() {
    clearInterval(quizState.timerInterval);

    // Calculate score
    let score = 0;
    quizState.questions.forEach((question, index) => {
        if (quizState.answers[index] === question.correctAnswer) {
            score += question.points;
        }
    });

    quizState.totalScore = score;

    // Calculate time taken
    const timeTaken = Math.floor((Date.now() - quizState.startTime) / 1000);

    // Save to user profile
    if (typeof saveQuizResultToProfile === 'function') {
        saveQuizResultToProfile({
            title: quizState.currentQuiz.title,
            score: score,
            totalQuestions: quizState.questions.length,
            timeTaken: timeTaken
        });
    }

    // Store detailed results for results page
    sessionStorage.setItem('quizResults', JSON.stringify({
        quiz: quizState.currentQuiz,
        score: score,
        answers: quizState.answers,
        questions: quizState.questions,
        timeTaken: timeTaken,
        result: {
            quizId: quizState.currentQuiz.id,
            quizTitle: quizState.currentQuiz.title,
            score: score,
            totalQuestions: quizState.questions.length,
            percentage: Math.round((score / (quizState.questions.length * 10)) * 100),
            timeTaken: formatTime(timeTaken),
            timestamp: new Date().toISOString()
        }
    }));

    // Navigate to results page
    window.location.href = 'results.html';
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function saveQuizResult(quizId, quizTitle, score, totalQuestions, timeTaken) {
    let userData = JSON.parse(localStorage.getItem('quizMasterUser'));
    
    const result = {
        quizId,
        quizTitle,
        score,
        totalQuestions,
        percentage: Math.round((score / (totalQuestions * 10)) * 100),
        timeTaken,
        timestamp: new Date().toISOString()
    };

    userData.quizHistory = userData.quizHistory || [];
    userData.quizHistory.push(result);
    userData.totalQuizzes = (userData.totalQuizzes || 0) + 1;
    userData.totalScore = (userData.totalScore || 0) + score;

    localStorage.setItem('quizMasterUser', JSON.stringify(userData));
    return result;
}

// Exit quiz early (called by exit button)
function exitQuiz() {
    const confirmed = confirm('Leave quiz now? Progress will not be saved.');
    if (confirmed) {
        clearInterval(quizState.timerInterval);
        window.location.href = 'quiz-selection.html';
    }
}
